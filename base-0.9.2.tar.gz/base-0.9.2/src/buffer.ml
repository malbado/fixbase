open! Import

include Buffer_intf

include Caml.Buffer

let add_substring t s ~pos ~len = add_substring t s pos len
let sexp_of_t t = sexp_of_string (contents t)

include Blit.Make_distinct
    (struct
      type nonrec t = t
      let create ~len = create len
      let length = length
    end)
    (struct
      type t = String.t
      let create ~len = String.create len
      let length = String.length
      let unsafe_blit ~src ~src_pos ~dst ~dst_pos ~len =
        Caml.Buffer.blit src src_pos dst dst_pos len
    end)
