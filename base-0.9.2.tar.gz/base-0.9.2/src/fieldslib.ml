(** This module is for use by ppx_fields_conv, and is thus not in the interface of
    Base. *)
module Field = Field
