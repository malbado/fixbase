#include <caml/mlvalues.h>

CAMLprim CAMLweakdef value Base_am_testing()
{
  return Val_false;
}
